*** INSTRUCTIONS FOR PLAYING ***

* For whatever reason, macOS always refuses to open up this game file and instead
tells you that it's "broken." This can be fixed, via these instructions below:

1. Open up Terminal
2. Navigate to the folder that contains the executable (cd)
3. When in the folder, run the following command:

    xattr -rc <Name of Executable>

Then the executable should work!

** I recognize that this is a really ugly solution and I am working on implementing
a solution to this!!
